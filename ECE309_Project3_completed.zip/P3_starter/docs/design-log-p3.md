# Project 3 Design Log
**Author:** Angelina Zhang  
**P2 code used:** instructor reference via `-DUSE_P2_REFERENCE=ON`  
**Tools used:** ChatGPT was used to review the project specification, discuss implementation choices, help draft tests, and review the completed code and design log. The implementation was then built and checked with the provided CMake/test workflow.

## 1. Hash table

I implemented `ToolRegistry` with **separate chaining**. The table is a `std::vector` of buckets, and each bucket is a `std::vector<std::unique_ptr<Tool>>`. I chose chaining instead of linear probing because removal is not required in this project, the representation is simple, and a collision only requires searching a short bucket rather than maintaining probing rules. It also makes `max_probe_length()` straightforward: it is the length of the longest chain.

The hash function is **64-bit FNV-1a**. It processes every character in order by XORing the character into the running hash and multiplying by the FNV prime. This makes the hash order-sensitive, unlike a weak hash such as `s[0] + s.size()`. The table starts with 16 buckets. Before an insertion that would raise the load factor above **0.75**, the table doubles its bucket count and rehashes every existing entry using the new bucket count.

For 10,000 tools named `tool_0` through `tool_9999`, my measurements were:

- bucket count: **16,384**
- load factor: **0.610352**
- maximum chain length: **6**
- weak-hash maximum chain length using `s[0] + s.size()`: **9000**

The weak hash groups most of these similarly named keys together, while FNV-1a spreads them across the table. `add()` is amortized O(1). Most insertions only hash the name and append to one short bucket. A resize costs O(n), but resizing only happens after many ordinary insertions, so that larger cost is spread across those operations.

## 2. Pointer stability

The registry owns every tool with `std::unique_ptr<Tool>`. A `Tool*` returned by `find()` points to the `Tool` object allocated on the heap, not to the `unique_ptr` object stored in a bucket. During rehashing I move the `unique_ptr`s into new buckets. Moving a `unique_ptr` changes which bucket owns the pointer, but it does not move the actual `Tool` object. Therefore the raw `Tool*` address stays the same across later resizes. The 10,000-tool test saves the first returned pointer and verifies that it is still identical after all resizing is complete.

## 3. Calculator trace

For `2 * (3 + 4) - 5`, the evaluator uses a value stack and an operator stack. First `2` goes onto values. `*` goes onto ops, then `(` goes above it. `3` goes onto values and `+` goes onto ops because `(` blocks operators outside the parentheses. `4` is pushed next. When `)` arrives, `+` is applied: `3` and `4` are popped, `7` is pushed, and the `(` is removed. The stacks now contain values `2, 7` and operator `*`.

When `-` arrives, `*` has higher precedence, so `2 * 7` is applied first and `14` is pushed. Then `-` is stored. Finally `5` is pushed. At the end, `14 - 5` is applied, leaving the single result **9**. Operands are popped right first and then left, which matters for subtraction and division. Equal precedence also uses `>=`, making operations such as `10 - 4 - 3` evaluate left to right.

## 4. Errors as values

Tool failures are normal events in this program. A requested file may not exist, a model may request an unsafe path, or a calculation may divide by zero. Returning `false` or `ToolResult::failure(...)` lets the harness place that failure into the conversation so the model can read it and react instead of terminating the program. Exceptions are more appropriate for programmer mistakes or violated internal assumptions, such as calling an accessor on the wrong JSON type. This separates recoverable tool input errors from bugs in the C++ program itself.

## 5. What I would design differently

If the public interface allowed it, I would avoid repeatedly calling `Tool::name()` during registry lookup and rehashing by storing each key beside its `unique_ptr`. The current design is correct and simple, but caching the name would avoid constructing temporary strings during repeated table operations.
